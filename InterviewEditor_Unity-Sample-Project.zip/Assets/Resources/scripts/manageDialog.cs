﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class manageDialog : MonoBehaviour
{
    // ----------------------------------------------------------------------------------------------------
    // CLASS: StoryBeat
    // ----------------------------------------------------------------------------------------------------
    public class StoryBeat
    {
        // Members.
        public int id;
        public string background_image;
        public string character_image;
        public StoryBeatType type;
        public string main_text;
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // CLASS: StoryBeatNarrative (inherits from Story Beat)
    // ----------------------------------------------------------------------------------------------------
    public class StoryBeatNarrative : StoryBeat
    {
        // Constructor, importing beat data.
        public StoryBeatNarrative(string[] data)
        {
            // Assign all of the members with what's provided in the data array.
            id = int.Parse(data[0]);
            background_image = data[1];
            character_image = data[2];
            type = (StoryBeatType)System.Enum.Parse(typeof(StoryBeatType), data[3]);
            main_text = data[4];
            next_id = int.Parse(data[5]);
        }

        // Constructor, converting from Choice beat.
        public StoryBeatNarrative(StoryBeatChoice oldBeat)
        {
            // Assign all of the members with what's provided in the data array.
            id = oldBeat.id;
            background_image = oldBeat.background_image;
            character_image = oldBeat.character_image;
            type = StoryBeatType.Narrative;
            main_text = oldBeat.main_text;
            next_id = -1;
        }

        // Constructor, adding new beat.
        public StoryBeatNarrative(int newID)
        {
            id = newID;
            background_image = "none";
            character_image = "none";
            type = StoryBeatType.Narrative;
            main_text = "__NEW__";
            next_id = -1;
        }

        // Members.
        public int next_id;
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // CLASS: StoryBeatChoice (inherits from StoryBeat)
    // ----------------------------------------------------------------------------------------------------
    public class StoryBeatChoice : StoryBeat
    {
        // Constructor, importing beat data.
        public StoryBeatChoice(string[] data)
        {
            // Assign all of the members with what's provided in the data array.
            id = int.Parse(data[0]);
            background_image = data[1];
            character_image = data[2];
            type = (StoryBeatType)System.Enum.Parse(typeof(StoryBeatType), data[3]);
            main_text = data[4];

            int dataIndex = 5;

            // Add all of the choices.
            for (int i = 0; i < 3; ++i)
            {
                // Initialize the choice object.
                choices[i] = new StoryChoice();

                // Set the choice ID. (1, 2, 3)
                choices[i].choice_id = int.Parse(data[dataIndex]);
                ++dataIndex;

                // Set the text for the choice.
                choices[i].choice_text = data[dataIndex];
                ++dataIndex;

                // Set the choice's next ID.
                choices[i].next_id = int.Parse(data[dataIndex]);
                ++dataIndex;
            }
        }

        // Constructor, converting from Narrative beat.
        public StoryBeatChoice(StoryBeatNarrative oldBeat)
        {
            // Assign all of the members with what's provided in the data array.
            id = oldBeat.id;
            background_image = oldBeat.background_image;
            character_image = oldBeat.character_image;
            type = StoryBeatType.Choice;
            main_text = oldBeat.main_text;

            // Add all of the choices with blank data.
            for (int i = 0; i < 3; ++i)
            {
                // Initialize the choice object.
                choices[i] = new StoryChoice();

                // Set the choice ID. (1, 2, 3)
                choices[i].choice_id = i + 1;

                // Set the text for the choice.
                choices[i].choice_text = "__NEW__";

                // Set the choice's next ID.
                choices[i].next_id = -1;
            }
        }

        // Constructor, adding new beat.
        public StoryBeatChoice(int newID)
        {
            // Assign all of the members with blank data.
            id = newID;
            background_image = "none";
            character_image = "none";
            type = StoryBeatType.Choice;
            main_text = "__NEW__";

            // Add all of the choices.
            for (int i = 0; i < 3; ++i)
            {
                // Initialize the choice object.
                choices[i] = new StoryChoice();

                // Set the choice ID. (1, 2, 3)
                choices[i].choice_id = i + 1;

                // Set the text for the choice.
                choices[i].choice_text = "__NEW__";

                // Set the choice's next ID.
                choices[i].next_id = -1;
            }
        }

        // Members.
        public StoryChoice[] choices = new StoryChoice[3];
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // CLASS: StoryChoice
    // ----------------------------------------------------------------------------------------------------
    public class StoryChoice
    {
        public int choice_id;
        public string choice_text;
        public int next_id;
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // MEMBERS: manageDialog variables
    // ----------------------------------------------------------------------------------------------------

    // Enum for story beat types.
    public enum StoryBeatType
    {
        Narrative,
        Choice
    }

    public TextAsset dialogFile;            // Text file containing the dialog data. (Set via Unity UI.)
    public GameObject narrativeUI;          // Prefab for the Narrative UI. (Set via Unity UI.)
    public GameObject choiceUI;             // Prefab for the Choice UI. (Set via Unity UI.)
    public SpriteRenderer backgroundImage;  // Background image sprite. (Set via Unity UI.)
    public SpriteRenderer characterImage;   // Character image sprite. (Set via Unity UI.)
    public Canvas canvasUI;                 // Canvas UI object.
    GameObject currentUI;                   // Game object for whatever the current UI is.
    List<StoryBeat> storyBeatList;          // List of all of the story beats.
    int currentBeatListIndex;               // Current index of the story beats list.

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Start - Initialization
    // ----------------------------------------------------------------------------------------------------
    void Start()
    {
        // Check to make sure that the dialog file was assigned.
        if (dialogFile != null)
        {
            // Put everything from the file into a single string.
            string fileContent = dialogFile.ToString();

            // Initialize the story beat list.
            storyBeatList = new List<StoryBeat>();

            // Check to make sure that the all lines string isn't empty.
            if (fileContent.Length > 0)
            {
                // Split the lines up into elements of an array.
                string[] fileLines = fileContent.Split('\n');

                // Go through the array and create objects.
                foreach (string currentLine in fileLines)
                {
                    // Check to make sure that the current line isn't blank.
                    if (currentLine.Length > 0)
                    {
                        // Split the current line up into its individual data.
                        string[] objectData = currentLine.Split('|');

                        // Check to make sure that the line was split into multiple pieces. (Otherwise, it wasn't properly formatted.)
                        if (objectData.Length > 3)
                        {
                            // Narrative object.
                            if (objectData[3] == "Narrative")
                            {
                                storyBeatList.Add(new StoryBeatNarrative(objectData));
                            }

                            // Choice object.
                            else if (objectData[3] == "Choice")
                            {
                                storyBeatList.Add(new StoryBeatChoice(objectData));
                            }
                        }
                    }
                }
            }
        }

        // Set the current UI game object to null by default.
        currentUI = null;

        // Load in the first beat.
        currentBeatListIndex = 0;
        loadBeat(storyBeatList[currentBeatListIndex].id);
	}

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Load the beat with the specified ID.
    // ----------------------------------------------------------------------------------------------------
    void loadBeat(int newID)
    {
        // Find the list index for the specified beat.
        int listIndex = findIndexByID(newID);

        // Check if an invalid index was returned, meaning that beat could not be found.
        if (listIndex == -1)
        {
            Debug.Log("ERROR: Unable to find specified beat: " + newID.ToString());
            return;
        }

        // Check if the beat is a Narrative beat.
        if (storyBeatList[listIndex].type == StoryBeatType.Narrative)
        {
            loadNarrativeUI(listIndex);
        }

        // Check if the beat is a Choice beat.
        else if(storyBeatList[listIndex].type == StoryBeatType.Choice)
        {
            loadChoiceUI(listIndex);
        }
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Finds the list index using the ID of the specified beat.
    // ----------------------------------------------------------------------------------------------------
    int findIndexByID(int newID)
    {
        // Go through the whole list of beats.
        for (int index = 0; index < storyBeatList.Count; ++index)
        {
            // Check if the current beat's ID matches the ID we're looking for.
            if (storyBeatList[index].id == newID)
            {
                return index;
            }
        }

        // If it got to this point, then it got through the whole list and didn't find that ID, so return -1, invalid index.
        return -1;
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Loads the necessary UI elements for a Narrative beat.
    // ----------------------------------------------------------------------------------------------------
    void loadNarrativeUI(int newIndex)
    { 
        // Check if there was a previous Narrative UI.
        if ((currentUI != null) && (storyBeatList[currentBeatListIndex].type == StoryBeatType.Narrative))
        {
            // Grab the old UI from the canvas.
            currentUI = canvasUI.transform.GetChild(0).gameObject;
        }

        // Check if there was a previous Choice UI.
        else if ((currentUI != null) && (storyBeatList[currentBeatListIndex].type == StoryBeatType.Choice))
        {
            // Destroy the old UI.
            Destroy(currentUI);

            // Create an instance of the UI.
            currentUI = Instantiate(narrativeUI);

            // Set the parent of the object to be the canvas so that it shows up as UI.
            currentUI.transform.SetParent(canvasUI.transform, false);
        }

        // Otherwise, there hasn't been any previous UI, so create new UI.
        else if (currentUI == null)
        {
            // Create an instance of the UI.
            currentUI = Instantiate(narrativeUI);

            // Set the parent of the object to be the canvas so that it shows up as UI.
            currentUI.transform.SetParent(canvasUI.transform, false);
        }

        // Update the current beat list index.
        currentBeatListIndex = newIndex;

        // Update background image.
        loadBackgroundImage(storyBeatList[currentBeatListIndex].background_image);

        // Update character image.
        loadCharacterImage(storyBeatList[currentBeatListIndex].character_image);

        // Get the text component from the UI.
        Text textUI = currentUI.GetComponentInChildren<Text>();

        // Update the text.
        textUI.text = storyBeatList[newIndex].main_text;
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Loads the necessary UI elements for a Choice beat.
    // ----------------------------------------------------------------------------------------------------
    void loadChoiceUI(int newIndex)
    {
        // Check if there was a previous Choice UI.
        if ((currentUI != null) && (storyBeatList[currentBeatListIndex].type == StoryBeatType.Choice))
        {
            // Grab the old UI from the canvas.
            currentUI = canvasUI.transform.GetChild(0).gameObject;
        }

        // Check if there was a previous Narrative UI.
        else if ((currentUI != null) && (storyBeatList[currentBeatListIndex].type == StoryBeatType.Narrative))
        {
            // Destroy the old UI.
            Destroy(currentUI);

            // Create an instance of the UI.
            currentUI = Instantiate(choiceUI);

            // Set the parent of the object to be the canvas so that it shows up as UI.
            currentUI.transform.SetParent(canvasUI.transform, false);
        }

        // Otherwise, there hasn't been any previous UI, so create new UI.
        else if (currentUI == null)
        {
            // Create an instance of the UI.
            currentUI = Instantiate(choiceUI);

            // Set the parent of the object to be the canvas so that it shows up as UI.
            currentUI.transform.SetParent(canvasUI.transform, false);
        }

        // Update the current beat list index.
        currentBeatListIndex = newIndex;

        // Update background image.
        loadBackgroundImage(storyBeatList[currentBeatListIndex].background_image);

        // Update character image.
        loadCharacterImage(storyBeatList[currentBeatListIndex].character_image);

        // Get the text component from the UI.
        Text textUI = currentUI.GetComponentInChildren<Text>();

        // Update the text.
        textUI.text = storyBeatList[newIndex].main_text;

        // Update buttons.
        Button[] buttonChoices = currentUI.GetComponentsInChildren<Button>();

        // Go through all of the buttons.
        for (int i = 0; i < buttonChoices.Length; ++i)
        {
            // Update the text on the button.
            Text buttonText = buttonChoices[i].GetComponentInChildren<Text>();
            buttonText.text = ((StoryBeatChoice)storyBeatList[currentBeatListIndex]).choices[i].choice_text;
        }

        // Add event listeners to choice buttons.
        buttonChoices[0].onClick.AddListener(delegate { eventChoiceButtonClicked(0); });
        buttonChoices[1].onClick.AddListener(delegate { eventChoiceButtonClicked(1); });
        buttonChoices[2].onClick.AddListener(delegate { eventChoiceButtonClicked(2); });
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Button event.
    // ----------------------------------------------------------------------------------------------------
    void eventChoiceButtonClicked(int choiceIndex)
    {
        // Load the selected choice's next beat.
        loadBeat(((StoryBeatChoice)storyBeatList[currentBeatListIndex]).choices[choiceIndex].next_id);
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Loads the background image.
    // ----------------------------------------------------------------------------------------------------
    void loadBackgroundImage(string backgroundImageName)
    {
        // Set the sprite for the background image to the specified image.
        backgroundImage.sprite = Resources.Load<Sprite>("images/backgrounds/" + backgroundImageName);
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Loads the character image.
    // ----------------------------------------------------------------------------------------------------
    void loadCharacterImage(string characterImageName)
    {
        // Check if there shouldn't be a character.
        if (characterImageName == "none")
        {
            characterImage.sprite = null;
        }

        // Otherwise, there is a character.
        else
        {
            // TODO: Maybe check if it's the same as the previous and don't change it then?
            characterImage.sprite = Resources.Load<Sprite>("images/characters/" + characterImageName);
        }
    }
    // ----------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------
    // FUNCTION: Update.
    // ----------------------------------------------------------------------------------------------------
    void Update()
    {
        // Click mouse button or press the space bar.
        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.Space))
        {
            // Check if the current beat is a Narrative beat.
            if (storyBeatList[currentBeatListIndex].type == StoryBeatType.Narrative)
            {
                // Load the next beat.
                loadBeat(((StoryBeatNarrative)storyBeatList[currentBeatListIndex]).next_id);
            }
        }

        // Press the 1 key on the top row or the num pad.
        if (Input.GetKeyDown(KeyCode.Alpha1) || Input.GetKeyDown(KeyCode.Keypad1))
        {
            // Check if the current beat is a Choice beat.
            if (storyBeatList[currentBeatListIndex].type == StoryBeatType.Choice)
            {
                // Load that choice's next beat.
                loadBeat(((StoryBeatChoice)storyBeatList[currentBeatListIndex]).choices[0].next_id);
            }
        }

        // Press the 2 key on the top row or the num pad.
        else if (Input.GetKeyDown(KeyCode.Alpha2) || Input.GetKeyDown(KeyCode.Keypad2))
        {
            // Check if the current beat is a Choice beat.
            if (storyBeatList[currentBeatListIndex].type == StoryBeatType.Choice)
            {
                // Load that choice's next beat.
                loadBeat(((StoryBeatChoice)storyBeatList[currentBeatListIndex]).choices[1].next_id);
            }
        }

        // Press the 3 key on the top row or the num pad. 
        else if (Input.GetKeyDown(KeyCode.Alpha3) || Input.GetKeyDown(KeyCode.Keypad3))
        {
            // Check if the current beat is a Choice beat.
            if (storyBeatList[currentBeatListIndex].type == StoryBeatType.Choice)
            {
                // Load that choice's next beat.
                loadBeat(((StoryBeatChoice)storyBeatList[currentBeatListIndex]).choices[2].next_id);
            }
        }
    }
    // ----------------------------------------------------------------------------------------------------
}
